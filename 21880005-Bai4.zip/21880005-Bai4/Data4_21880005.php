<?php

$dsSV=array(

        ['2207728','Hoàng Thị Thanh Hương',9.5,'../images/2207728.png'],
        ['2207744','Đỗ Thị Bích Ngọc',5.7,'../images/2207744.png'],
        ['2207799','Mai Đinh Ngọc Thủy',7.4,'../images/2207799.png'],
        ['2207832','Võ Đạt',5.7,'../images/2207832.png'],
        ['2207978','Lê Hải Phong',7.3,'../images/2207978.png'],
        ['2208055','Nguyễn Thị Hải',9.5,'../images/2208055.png'],
        ['2208063','Lê Thị Đào',5,'../images/2208063.png'],
        ['2208060','Nguyễn Thị Thanh Nhàn',7.2,'../images/2208060.png'],
        ['2208092','Lê Văn Phong',6.5,'../images/2208092.png'],
        ['2208096','Nguyễn Thị Thanh Hương',5.2,'../images/2208096.png'],
        ['2208098','Nguyễn Thị Thanh Tú',4.5,'../images/2208098.png'],
        ['2208201','Nguyễn Thị Kiều Trang',8,'../images/2208201.png'],
        ['2210881','Trần Đình Thông',5.1,'../images/2210881.png'],
        ['2210844','Nguyễn Hữu Thịnh',4.8,'../images/2210844.png'],
        ['2210683','Nguyễn Thị Thanh Giang',4.9,'../images/2210683.png'],
        ['2210681','Trần Chí Tâm',9.9,'../images/2210681.png'],
        ['2210687','Phạm Thanh Long',8.9,'../images/2210687.png'],
        ['2210688','Ngô Tuấn Anh',4.6,'../images/2210688.png'],
        ['2210624','Nguyễn Hoàng Phi Vũ',9.1,'../images/2210624.png'],
        ['2212158','Nguyễn Tấn Viện',5.4,'../images/2212158.png']
    );

//printData($dsSV);


